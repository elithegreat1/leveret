Window.BundledItems = [];
Window.ProductHandles = [];
Window.selectedSet = {
    handle : undefined,
    size  : undefined,
    color: undefined
}

function getProductJSON(handle,callback){
    $.ajax({
        dataType: "json",
        url: `${handle}`,
        async: true, 
        success: function(data) {
            callback(data);
        }
    });
}


function clearSelectedCategorys(){
    document.querySelectorAll('.product_bundler-step_category').forEach( category => {
        category.classList.remove("product_bundler-step_category_active")
    });
}

function clearSelectedSets(){
    document.querySelectorAll('.product_bundler-step_set').forEach( set => {
        set.classList.remove("active_set")
    });
}

function clearSelectedSizes(){
    document.querySelectorAll('.product_bundler-step_size').forEach( size => {
        size.classList.remove("active-size")
    });
}

function clearSelectedColors(){
    document.querySelectorAll('.colorSwatch').forEach(color => {
        color.classList.remove("active-color")
    });
}

function addCategoryListener(){
    document.querySelectorAll('.product_bundler-step_category').forEach( category => {
        category.addEventListener('click', () => {
            clearSelectedCategorys();
            category.classList.add("product_bundler-step_category_active")
            document.getElementById('bundler-step_3').style.display = "none"
            displaySetsData(getSetsFromCategory(` ${category.innerHTML.toLowerCase()}`))
            document.getElementById('bundler-step_2').style.display = "none"
            setTimeout(() => {
                $(document.getElementById('bundler-step_2')).slideToggle()
                setTimeout(() => {
                    $('html, body').animate({
                        scrollTop: $("#step_label_2").offset().top - 270
                    }, 1000);
                }, 400);    
            }, 500);
        });
    });
}

function addThumbnailListener(){
    document.querySelectorAll('.thumbnail_image').forEach( thumbnail => {
        thumbnail.addEventListener('click', () => {
            let featuredImage = document.getElementById('productFeaturedImage');
            let thumbnailImage = thumbnail.src;
            if (featuredImage.src != thumbnailImage) {
                featuredImage.src = thumbnailImage;
            }
        });
    });
}

function getSetsFromCategory(selected_category){
    return Window.ProductHandles.filter(handle => (handle.toLowerCase()+"#").includes(selected_category + "#") == true)
}

function setSelectedSet(set,selected_set){
    Window.selectedSet.handle = selected_set
    clearSelectedSets();
    set.classList.add('active_set')
    getProductJSON(`/products/${selected_set}.js`,(product) => {
        setStepThreeData(product.featured_image,product.title,`$${product.price / 100}`,product.description,product.compare_at_price)
        console.log('product', product)
        displayColors(product.tags)
        displaySizes(product.variants)
    })
    document.getElementById('bundler-step_3').style.display = "none"
    setTimeout(() => {
        $(document.getElementById('bundler-step_3')).slideToggle()
        setTimeout(() => {
            $('html, body').animate({
                scrollTop: $("#step_label_3").offset().top - 130
            }, 1000);
        }, 400);  
    }, 500);
}

function setStepThreeData(image,title,price,description,comparePrice){
    document.querySelectorAll('.product_bundler-product_image').forEach( stepThreeImage =>{
        stepThreeImage.src = image;
    });
    document.querySelectorAll('.product_bundler-product_title').forEach( stepThreeTitle =>{
        stepThreeTitle.innerHTML = title;
    });
    document.querySelectorAll('.product_bundler-product_price').forEach( stepThreePrice =>{
        stepThreePrice.innerHTML = price;
    });
    document.querySelectorAll('.product_bundler-product_description').forEach( stepThreeDescription =>{
        stepThreeDescription.innerHTML = description;
    });

    if(comparePrice != null){
        document.querySelectorAll('.product_bundler-product_price-old').forEach( stepThreeComparePrice =>{
            stepThreeComparePrice.style.display = "block"
            stepThreeComparePrice.innerHTML = `$${(comparePrice / 100).toFixed(2)}`;
        });
    }else{
        document.querySelectorAll('.product_bundler-product_price-old').forEach( stepThreeComparePrice =>{
            stepThreeComparePrice.style.display = "none"
        });
    }
}

function selectSize(sizeElement, size){
    if(sizeElement.getAttribute("disabled") == undefined){
        Window.selectedSet.size = size;
        clearSelectedSizes();
        sizeElement.classList.add('active-size')
        onOptionsSelected(false);
    }
}

function selectColor(colorElement, color){
    Window.selectedSet.color = color;
    clearSelectedColors();
    colorElement.classList.add('active-color')
    onOptionsSelected(true);
}

function displayColors(tags){
    let colorTags = tags.filter(tag => tag.includes('Color |') == true);
    console.log('colorTags',colorTags)
    let colorsContainer = document.querySelector('#product_bundler-step_colors');
    colorsContainer.innerHTML = ''
    for(let i = 0; i < colorTags.length; i++){
        let color = colorTags[i];
        let colorName = color.split(" | ")[1];
        let hex = color.split(" | ")[2];

        //marksoldout
        let temp = getInventories();
        let availableVariants = temp.filter(variant => variant.identifier.includes(`${Window.selectedSet}`));
        

        colorsContainer.innerHTML = colorsContainer.innerHTML + `<div class="colorSwatch ${colorName}" onclick="selectColor(this,'${colorName}')" style="background:${hex};" title="${colorName}"></div>`;

    }


    if(colorsContainer.childNodes.length != 0){
        colorsContainer.childNodes[0].click(); 
    }

    
}

function displaySizes(variants){ 
    let sizes = document.querySelector('#product_bundler-step_sizes');
    sizes.innerHTML = ''
    variants = variants.filter(variant => variant.option1 == document.querySelector('.active-color').title) 
    for(let i = 0; i < variants.length; i++){
        let variant = variants[i];
        if(!sizes.innerHTML.includes(`class="product_bundler-step_size" onclick="selectSize(this,'${variant.option2}')">${variant.option2}</span>`)){
            sizes.innerHTML = sizes.innerHTML + `<span data-variantid="${variant.id}" class="product_bundler-step_size" onclick="selectSize(this,'${variant.option2}')">${variant.option2}</span>` 
        }
    }

    markAsSoldOut();

    if(sizes.childNodes.length){
        if(document.getElementsByClassName('product_bundler-step_size')[0].getAttribute("disabled") == null){
            document.getElementsByClassName('product_bundler-step_size')[0].click()
        }
        
    }

    document.querySelector('#product-atc').style.display = "block"

}

function displaySetsData(handles){
    let set_options = document.querySelector('#bundler-step_2').querySelector('.product_bundler-step_sets');
    set_options.innerHTML = ''
    for(let i = 0; i < handles.length; i++) {
        let handle = handles[i].split(' | ')[1];
        getProductJSON(`/products/${handle}.js`, (product) => {
            set_options.innerHTML = set_options.innerHTML + `<span class="product_bundler-step_set" onclick="setSelectedSet(this,'${product.handle}')"> <img src="${product.featured_image}"> </span>`
        })
    }

}

function addClearListeners(){
    let clear_step_2 = document.getElementById('bundler-clear-2')
    let clear_step_3 = document.getElementById('bundler-clear-3')

    clear_step_2.addEventListener('click', () => {
        clearSelectedSets();
        document.getElementById('bundler-step_3').style.display = "none"
        Window.selectedSet.handle = undefined;
        Window.selectedSet.size = undefined;
        Window.selectedSet.color = undefined;
    });

    clear_step_3.addEventListener('click', () => {
        clearSelectedSizes();
        clearSelectedColors();
        Window.selectedSet.size = undefined;
        Window.selectedSet.color = undefined;

        document.querySelector('#product-atc').style.display = "none"
        
        $(document.getElementById('bundler-step_3')).slideToggle()
        document.querySelector('.active_set').classList.remove('active_set')
        
        setTimeout(() => {
            $('html, body').animate({
                scrollTop: $("#step_label_2").offset().top - 270
            }, 1000);  
        }, 400);


    });

}

function DOMreadyBundler(callback) {
  if (document.readyState != 'loading') callback();
  else document.addEventListener('DOMContentLoaded', callback);
}

DOMreadyBundler(()=>{
  addCategoryListener();
  addThumbnailListener();
  addClearListeners();
  addToCartListeners();
  getProductJSON(`${window.location.pathname}.js`,(product) => {
      for(let i = 0; i < product.tags.length; i++){
          let tag = product.tags[i];
          if(tag.includes("Product |")){
              Window.ProductHandles.push(tag)
          }
      }
      hideEmptyTabs();
  })
})

function addToCartListeners(){
    document.getElementById('product-atc').addEventListener('click', () =>{
        getProductJSON(Window.selectedSet.handle, (data) => {
            let product = data.product;
            let variant = product.variants.filter(variant => variant.title == `${Window.selectedSet.color} / ${Window.selectedSet.size}`)[0]
            let image = document.getElementsByClassName('product_bundler-product_image')[0];
            addItemToCart(variant,image.src)
            
        })
    })
}

document.querySelectorAll('.product_instructions-button').forEach( modalTrigger => {
    modalTrigger.addEventListener('click', () =>{
        let modalEl = document.getElementById('instructions_modal');
        let bodyEl = document.body;
        modalEl.classList.add('instructions_modal--active');
        bodyEl.style.overflow = "hidden"
    });
});

document.querySelectorAll('.product_instructions-close').forEach( modalTrigger => {
    modalTrigger.addEventListener('click', () =>{
        let modalEl = document.getElementById('instructions_modal');
        let bodyEl = document.body;
        modalEl.classList.remove('instructions_modal--active');
        bodyEl.style.overflow = ""
    });
});

function onOptionsSelected(colorchanged){
    if(Window.selectedSet.size != undefined && Window.selectedSet.color != undefined){

        if(colorchanged){
            getProductJSON(Window.selectedSet.handle, (data) => {
                displaySizes(data.product.variants)
                document.getElementsByClassName('product_bundler-step_size')[0].click()
            })
        }

        getProductJSON(Window.selectedSet.handle, (data) => {
            let step3Image = document.querySelectorAll('.product_bundler-product_image');
            let step2Image = document.querySelector('.active_set').firstElementChild;
            let product = data.product;
            let variantImageFilter = product.variants.filter(variant => variant.title == `${Window.selectedSet.color} / ${Window.selectedSet.size}`)[0]
            if(variantImageFilter != undefined){
                let variantImage = product.images.filter(image => image.id == variantImageFilter.image_id)[0].src
                step3Image.forEach((image) => {
                    image.src = variantImage;
                })
                step3Image.src = variantImage; 
            }else{
                let availableSizes = product.variants.filter(variant => variant.option1 == Window.selectedSet.color);
                displaySizes(availableSizes);
                markAsSoldOut();
                document.getElementsByClassName('product_bundler-step_size')[0].click()
                
            }   

        })
    }
}

function addItemToCart(variant, img) {

    data = {
      "id": Number(variant.id),
      "quantity": 1
    }
    jQuery.ajax({
      type: 'POST',
      url: '/cart/add.js',
      data: data,
      dataType: 'json',
      success: function () {
        let container = document.getElementById("cart-items-container");
        let cartcontainer = document.querySelector('.product_cart-outer');
        getProductJSON(Window.selectedSet.handle, (data) => {
            cartcontainer.style.display = "block"
            let product = data.product;
            if(document.getElementById(Window.selectedSet.handle + `_${Window.selectedSet.color}-${Window.selectedSet.size}_item`) == undefined){
                container.innerHTML = container.innerHTML + cartItem(Window.selectedSet.handle + `_${Window.selectedSet.color}-${Window.selectedSet.size}_item`, img,product.title,`${Window.selectedSet.color} / ${Window.selectedSet.size}`,variant.id)
            }else{
                let qs = document.getElementById(Window.selectedSet.handle + `_${Window.selectedSet.color}-${Window.selectedSet.size}_item`).querySelector('.product_cart-quantity_input');
                qs.setAttribute('value',`${Number(qs.getAttribute('value')) + 1}`);
            }
            
        })
        let button = document.querySelector('#product-atc');
        let button_msg = document.querySelector('#product-atc-msg');
        button.innerHTML = "ADDED TO CART";
        button.style.background = "#535353";
        button_msg.style.display = "flex";

        let cartTotal = document.querySelector('.product_cart-subtotal');
        let currentValue = Number(cartTotal.firstElementChild.innerHTML.split("$")[1]);
        cartTotal.firstElementChild.innerHTML = ` $${(currentValue + Number(variant.price)).toFixed(2)}`

        setTimeout(() => {
            document.querySelector('#product-atc').innerHTML = "ADD TO CART"
            button_msg.style.display = "none"
            button.style.background = "#000000";

        }, 3000);


        setTimeout(() => {
            $('html, body').animate({
                scrollTop: $("#product_cart-subtotal_flex").offset().top - 150
            }, 1000);
        }, 1000);


      },
  
      error: function (xhr, a, b) {
        alert("Sorry, That item is not available");
      }
    });
}

function cartItem(handle,img,title,selection,variant){
    console.log('variant', variant)
    let id = handle.replace("_item","");
    console.log('id:', id)
    let phandle = id.split('_')[0]
    let obj = getInventories().filter(variant => variant.identifier == `${phandle} - ${selection}`)[0];
    let variant_to_remove = getInventories().filter(variant => variant.identifier == `${phandle} - ${selection}`)[0];
    console.log(`${phandle} - ${selection}`)
    console.log(variant_to_remove)
    let vid =  Number(variant_to_remove.variant_id);
    return `
    <div id="${handle}" data-vid="${vid}" data-price="${variant_to_remove.variant_price / 100}" class="product_cart-cart_item">
        <a href="javascript:void(0)" class="product_cart-remove_item" onclick="removeItemFromCart(this)">
            <?xml version="1.0" encoding="iso-8859-1"?>
            <!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
            <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                viewBox="0 0 512.001 512.001" style="enable-background:new 0 0 512.001 512.001;" xml:space="preserve">
                <g>
                    <g>
                        <path d="M284.286,256.002L506.143,34.144c7.811-7.811,7.811-20.475,0-28.285c-7.811-7.81-20.475-7.811-28.285,0L256,227.717
                            L34.143,5.859c-7.811-7.811-20.475-7.811-28.285,0c-7.81,7.811-7.811,20.475,0,28.285l221.857,221.857L5.858,477.859
                            c-7.811,7.811-7.811,20.475,0,28.285c3.905,3.905,9.024,5.857,14.143,5.857c5.119,0,10.237-1.952,14.143-5.857L256,284.287
                            l221.857,221.857c3.905,3.905,9.024,5.857,14.143,5.857s10.237-1.952,14.143-5.857c7.811-7.811,7.811-20.475,0-28.285
                            L284.286,256.002z"/>
                    </g>
                </g>
            </svg>
        </a>
        <div class="product_cart-item_image">
            <img src="${img}">
        </div>
        <div class="product_cart-item_info">
            <span class="product_cart-item_title">${title}</span>
            <span class="product_cart-item_desc">${selection}</span>
            <div class="product_cart-quantity_outer">
                <span class="product_cart-item_title">QUANTITY</span>
                <div class="quantity_controls">
                    <button class="quantity_control quantity_control-deduct" onclick="onQuantityChange(this);">-</button>
                    <input type="number" class="product_cart-quantity_input" value="1" disabled>
                    <button class="quantity_control quantity_control-add" onclick="onQuantityChange(this);">+</button>
                </div>
            </div>
        </div>
    </div>
    
    `
}

function onQuantityChange(element){
    let itemContainer = element.parentElement.parentElement.parentElement.parentElement;
    let quantity_selector = itemContainer.querySelector('.product_cart-quantity_input');
    let items = document.getElementsByClassName('product_cart-cart_item');
    let price = document.querySelector('.product_cart-subtotal').firstElementChild;

    if(element.innerHTML == "-"){
        quantity_selector.setAttribute('value',Number(quantity_selector.value) - 1);
    }else if(element.innerHTML == "+"){
        quantity_selector.setAttribute('value',Number(quantity_selector.value) + 1);
    }
    price.innerHTML = '0';

    for(let i = 0; i < items.length; i++){
        let item = items[i];
        price.innerHTML = Number(price.innerHTML) + (Number(item.dataset.price  * item.querySelector('.product_cart-quantity_input').value))
        
        if(item.querySelector('.product_cart-quantity_input').value == "0"){
            jQuery.post('/cart/update.js',
            `updates[${item.dataset.vid}]=0`
             );
            item.remove();
            if(items.length == 0) {
                document.getElementsByClassName('product_cart-outer')[0].style.display = "none";
            }
        }else{     
            jQuery.ajax({
                type: 'POST',
                url: '/cart/update.js',
                data: `updates[${item.dataset.vid}]=${item.querySelector('.product_cart-quantity_input').value}`,
                dataType: 'json',
                async: false,
                success: function () {
                },
            
                error: function (xhr, a, b) {
                  
                }
              });

        }
    }
    price.innerHTML = `$${Number(price.innerHTML).toFixed(2)}`
}

function gotoTop(){
    $('html, body').animate({
        scrollTop: $("#step_label_2").offset().top - 270
    }, 1000);
}

function removeItemFromCart(element){
    let parent = element.parentElement;
    let id = parent.id.replace("_item","");
    let handle = id.split('_')[0]
    let cas = parent.querySelector('.product_cart-item_desc').innerHTML
    let obj = getInventories().filter(variant => variant.identifier == `${handle} - ${cas}`)[0];
    let idToRemove = getInventories().filter(variant => variant.identifier == `${handle} - ${cas}`)[0].variant_id;
    let vid =  Number(idToRemove);
    let price = document.querySelector('.product_cart-subtotal').firstElementChild.innerHTML.split("$")[1];
    let oldPrice = Number(price)
    let newPrice = oldPrice - ((obj.variant_price / 100) * Number(parent.querySelector('.product_cart-quantity_input').value));

    document.querySelector('.product_cart-subtotal').firstElementChild.innerHTML = `$${newPrice.toFixed(2)}`
    if(newPrice == 0){
        document.getElementsByClassName('product_cart-outer')[0].style.display = "none";
    }
    jQuery.post('/cart/update.js',
    `updates[${vid}]=0`
     );
     parent.remove();
}

function expandImage(element){
    const container = document.querySelector('.img-lightbox');
    const contentLight = document.querySelector('.lightbox-img');
    container.style.display = "block";
    contentLight.src = document.querySelectorAll('.product_bundler-product_image')[0].src
}

function closeLightBox(){
    document.getElementById('img-lightbox').style.display = "none";
}

function replaceLast(x, y, z){
    let a = x.split("");
    a[x.lastIndexOf(y)] = z;
    return a.join("");
}

function getInventories(){
    return JSON.parse(replaceLast(document.getElementById("inventory-quantities").innerHTML.trim().replaceAll('\"','"'),",",""))
}

function markAsSoldOut(){
    let sizes = document.getElementsByClassName("product_bundler-step_size");
    for(let i = 0; i < sizes.length; i++){
        let size = sizes[i];
        let temp = getInventories();
        let availableVariants = temp.filter(variant => variant.identifier == `${Window.selectedSet.handle} - ${Window.selectedSet.color} / ${size.innerHTML}`);
        if(availableVariants.length > 0 && !availableVariants[0].available){
            size.classList.add("disable_size")
            size.setAttribute('disabled','')
        }
    }
    
}

window.onclick = function(event) {
    let docBody = document.body;

    let expanderModal = document.getElementById('img-lightbox');
    if (event.target == expanderModal) {
        expanderModal.style.display = 'none';
    }

    let instructionsModal = document.querySelector('#instructions_modal');
    let instructionsWindow = document.querySelector('.product_instructions-outer');
    if (event.target == instructionsWindow) {
        instructionsModal.classList.remove('instructions_modal--active');
        docBody.style.overflow = ""
    }
}


function hideEmptyTabs(){

    let tabs = document.querySelectorAll('.product_bundler-step_category');

    tabs.forEach(tab => {
        console.log(getSetsFromCategory(` ${tab.innerHTML.toLowerCase()}`))
        if(getSetsFromCategory(` ${tab.innerHTML.toLowerCase()}`).length == 0){
            tab.style.display = "none"
        }else{
            tab.style.opacity = 1;
        }
    })

}